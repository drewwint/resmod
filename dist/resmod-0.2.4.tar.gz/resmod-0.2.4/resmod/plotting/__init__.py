#!/usr/bin/python3

from .interact_plot import interact_plot

__all__ = ["interact_plot"]
