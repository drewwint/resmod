#!/usr/bin/python3

from .simple_slopes import simple_slopes

__all__ = ["simple_slopes"]
