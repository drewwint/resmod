#!/usr/bin/python3

from resmod.single.residual_center import residual_center  #two-way interaction

