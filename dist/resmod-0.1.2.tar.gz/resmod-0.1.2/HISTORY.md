

History
=======

0.1.0 (2022-08-27)
------------------
Created the first function *residual_center*


* First release on PyPI.

0.1.1 (2022-08-28)
------------------
Updated documentation 

0.1.2 (2022-08-30)
------------------
Added functions for three-way interactions and multiple two-way interactions for specifying latent orthogonalized interaction terms for use in latent varaible SEM

* for single three-way interaction term *three_way*
* for multiple interactions for latent variable modeling *orthogonalize*

