Primary Authors
===============

* __[Drew E. Winters, PhD.](https://github.com/drewwint)__

	* __[personal website](https://www.drewewinters.com/)__



