
=======
History
=======

0.1.0 (2022-08-27)
------------------
Created the first function *residual_center*


* First release on PyPI.
